//
//  AppDelegate.h
//  ProtobufDemo
//
//  Created by LeeWong on 2018/3/30.
//  Copyright © 2018年 LeeWong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

